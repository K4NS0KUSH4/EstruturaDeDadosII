Acesse a pasta "src" para obter acesso ao código-fonte do projeto.

Caso o programa não compile, apresentando algum erro do tipo "java cannot find symbol",
considere rebuildar o projeto. Durante o desenvolvimento da atividade, encontramos 
dificuldade em configurar corretamente o classpath dos projetos.